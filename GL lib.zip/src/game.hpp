#ifndef ABCD
#   include <nlohmann/json.hpp>
#   include <string>
#   include <vector>
#   include <algorithm>
#   endif

namespace Mistical {
    class Entity {
        public:
            template <typename T> T getData(const std::string& key);
            void setData(const std::string& key, int value);
            void setData(const std::string& key, double value);
            void setData(const std::string& key, float value);
            void setData(const std::string& key, std::string value);
            void setData(const std::string& key, bool value);
            void setPos(int x, int y);
            void move(int x, int y);
        protected:
            int posX, posY;
        private:
            nlohmann::json data;
            //texture
    };

    template <> int         Entity::getData<int>(const std::string& key) {
        return data[key].get<int>();
    }
    template <> double      Entity::getData<double>(const std::string& key) {
        return data[key].get<double>();
    }
    template <> float       Entity::getData<float>(const std::string& key) {
        return data[key].get<float>();
    }
    template <> std::string Entity::getData<std::string>(const std::string& key) {
        return data[key].get<std::string>();
    }
    template <> bool        Entity::getData<bool>(const std::string& key) {
        return data[key].get<bool>();
    }
    void Entity::setData(const std::string& key, int value) {
        data[key] = value;
    }
    void Entity::setData(const std::string& key, double value) {
        data[key] = value;
    }
    void Entity::setData(const std::string& key, float value) {
        data[key] = value;
    }
    void Entity::setData(const std::string& key, std::string value) {
        data[key] = value;
    }
    void Entity::setData(const std::string& key, bool value) {
        data[key] = value;
    }
    void Entity::setPos(int x, int y) {
        posX = x;
        posY = y;
    }
    void Entity::move(int x, int y) {
        posX += x;
        posY += y;
    }


    class Player: public Entity {
        public:
            void update();
        protected:
            void updateBuffers();
            void updateVelocity();
        private:
            static const int jumpBuffer, dashBuffer;
            static const int hitbox[2][2];
            double velocityX, velocityY;
    };

    void Player::update() {
        updateBuffers();
        updateVelocity();
    }
    void Player::updateBuffers() {}
    void Player::updateVelocity() {}

    class Tile {
        public:
            Tile(const char* pPath, float x, float y);
            void updateSprite(const std::vector<int> &neighbours);
            void updateSprite(const std::initializer_list<std::vector<int>> &neighbours);
            inline static std::array<float, 2> rptwp(int iPosX, int iPosY); // room pos to window pos;
            //void updateSprite(int neighbours[8]);
            //void updateSprite(std::initializer_list<int> neighbours[8]);
            //void updateSprite(int neighbours[24]);
            //void updateSprite(std::initializer_list<int> neighbours[24]);
            std::vector<int> checkNeighbours(int neighboursCount);
            static void setShader(Mistical::Shader* pShader);
            void draw();
            inline static const int tilesWidth = 40, tilesHeight = 23;
            inline static float tileWidth, tileHeight;
        private:
            char* typeId;
            const char* path;
            AnimatedSprite sprite;
            inline static Mistical::Shader* shader;
            nlohmann::json tileJson;
            //static ; tile size ig??
    };

    Tile::Tile(const char* pPath, float x, float y) {
        path = pPath;
        tileJson = JSON::ParseJSONFile(path);
        if (!tileJson.contains("type")) {
            Console::error("Failed to load file %s - Missing key \"type\"", pPath);
            return;
        }
        std::string type = tileJson["type"].get<std::string>();
        if (type == "simple")   updateSprite(checkNeighbours(1));
        else if (type == "3x3") updateSprite(checkNeighbours(8));
        else if (type == "5x5") updateSprite(checkNeighbours(24));
        else {
            Console::error("Expected key \"type\" to be either \"simple\", \"3x3\" or \"5x5\", but it is \"%s\"", tileJson["type"].get<std::string>().c_str());
        }
        sprite.position(x + tileWidth, y + tileHeight);
        sprite.size(tileWidth * 2, tileHeight * 2);
    }
    void Tile::updateSprite(const std::vector<int> &neighbours) {
        if (neighbours.size() == 1) {
            const char* spritePath = tileJson["asset"].get<std::string>().c_str();
            sprite.loadFromPath(spritePath, shader);
            return;
        }
        // const nlohmann::json tileJson = JSON::ParseJSONFile(path);
        std::size_t casesCount = static_cast<int>(tileJson["cases"].size());
        for (std::size_t i = 0; i < casesCount; i++) {
            for (std::size_t j = 0; j < tileJson["cases"][i]["neighbours"].size(); j++) {
                // if (tileJson["cases"][i]["neighbours"][j].size() != 8) {
                //     Console::error("Expected array size to be exactly 8 but is %s", tileJson["cases"][i]["neighbours"].size());
                //     return;
                // };
                if (!tileJson["cases"][i]["neighbours"][j].is_array()) {
                    Console::error("");
                }
                std::vector<int> neighboursArray = tileJson["cases"][i]["neighbours"][j].get<std::vector<int>>();
                if (neighbours == neighboursArray) {
                    sprite.loadFromPath(("data/assets/" + tileJson["cases"][i]["asset"].get<std::string>()).c_str(), shader);
                    return;
                }
            }
        }
        sprite.loadFromPath(tileJson["fallback"].get<std::string>().c_str(), shader);
    }
    std::vector<int> Tile::checkNeighbours(int neighboursCount) {
        if (neighboursCount == 1) {
            return std::vector<int>{1};
        }
        return std::vector<int>{1, 1, 1, 1, 1, 1, 1, 1};
    }
    void Tile::setShader(Mistical::Shader* pShader) {
        shader = pShader;
    }
    void Tile::draw() {
        sprite.draw();
    }

    std::array<float, 2> Tile::rptwp(int iPosX, int iPosY) { //! @brief Room Pos To Window Pos - Converts a tile position to a window coordinate
        //Console::log("ABCD: %f, %f; %d, %d", Tile::tileWidth, Tile::tileHeight, iPosX, iPosY);
        return {
            (Tile::tileWidth * iPosX) * 2.0f - 1.0f,
            (Tile::tileHeight * iPosY) * 2.0f - 1.0f
        };
    }

    class Room {
        public:
            Room(const char* path);
            void updateTiles();
            int getTilesSize();
        private:
            int height, width;
            nlohmann::json roomJson;
            std::vector<Tile> roomTiles;
            bool checkpoint;
            //template <typename T> T objects[];
    };

    Room::Room(const char* path) {
        roomJson = JSON::ParseJSONFile(path);
        if (!roomJson.contains("height")) {
            Console::error("Missing key \"height\" in json %s", path);
            return;
        }
        if (!roomJson.contains("width")) {
            Console::error("Missing key \"width\" in json %s", path);
            return;
        }
        if (!roomJson.contains("tiles")) {
            Console::error("Missing key \"tiles\" in json %s", path);
            return;
        }
        if (!roomJson["tiles"].is_array()) {
            Console::error("Expected key \"tiles\" to be an array - %s", path);
            return;
        }
        height = roomJson["height"].get<int>();
        width = roomJson["width"].get<int>();
        checkpoint = roomJson.value("checkpoint", false);
        roomTiles.reserve(height * width);
        for (int i = 0; i < roomJson["tiles"].size(); i++) {
            if (!roomJson["tiles"][i].contains("from")) {
                Console::error("Missing key \"from\" in json %s", path);
                return;
            }
            if (!roomJson["tiles"][i].contains("to")) {
                Console::error("Missing key \"to\" in json %s", path);
                return;
            }
            if (!roomJson["tiles"][i]["from"].is_array()) {
                Console::error("Expected key \"from\" to be an array - %s", path);
                return;
            }
            if (!roomJson["tiles"][i]["to"].is_array()) {
                Console::error("Expected key \"to\" to be an array - %s", path);
                return;
            }
            if (roomJson["tiles"][i]["from"].size() != 2) {
                Console::error("Expected size of arrray \"from\" to be exactly 2 - %s", path);
                return;
            }
            if (roomJson["tiles"][i]["to"].size() != 2) {
                Console::error("Expected size of arrray \"to\" to be exactly 2 - %s", path);
                return;
            }
            int fromX = roomJson["tiles"][i]["from"][0].get<int>();
            int fromY = roomJson["tiles"][i]["from"][1].get<int>();
            int rectHeight = roomJson["tiles"][i]["to"][1].get<int>() - fromY + 1;
            int rectWidth = roomJson["tiles"][i]["to"][0].get<int>() - fromX + 1;
            if (rectHeight < 0 || rectWidth < 0) {
                Console::error("Expected size to be atleast 0 x 0 but is %d x %d - %s", rectWidth, rectHeight, path);
                return;
            }
            bool breakLoop = false;
            //Console::debug("Height: %d, Width: %d", rectHeight, rectWidth);
            //Console::debug("wH: %d, wW: %d", Tile::rptwp(rectWidth, rectHeight)[1], Tile::rptwp(rectWidth, rectHeight)[0]);
            //Console::debug("fromX: %d, fromY: %d", fromX, fromY);
            //Console::debug("tsWPX: %d, tsWPY: %d", Tile::rptwp(fromX, fromY)[1], Tile::rptwp(fromX, fromY)[0]);
            for (int j = fromY; j < rectHeight + fromY && !breakLoop; j++) {
                for (int k = fromX; k < rectWidth + fromX; k++) {
                    std::array<float, 2> windowTilePos = Tile::rptwp(k, j);
                    //Tile currentTile(roomJson["tiles"][i]["tile"].get<std::string>().c_str(), windowTilePos[0], windowTilePos[1]);
                    roomTiles.emplace_back(roomJson["tiles"][i]["tile"].get<std::string>().c_str(), windowTilePos[0], windowTilePos[1]);
                    //Console::log("Test: %f, %f", Tile::rptwp(k, j)[0], Tile::rptwp(k, j)[1]);
                    //Console::log("X: %d, Y: %d; tWPX: %f, tWPY %f", k, j, windowTilePos[0], windowTilePos[1]);
                }
            }
            //Console::debug("Size: %d", roomTiles.size());
        }
    }
    void Room::updateTiles() {
        for (int i = 0; i < roomTiles.size(); i++) {
            roomTiles[i].draw();
        }
    }
    int Room::getTilesSize() {
        return roomTiles.size();
    }
}
