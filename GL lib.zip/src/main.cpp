#define ABCD
#define STB_IMAGE_IMPLEMENTATION
#include <iostream>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <stb/stb.h>
#include <glm/glm.hpp>
#include <fstream>
#include <sstream>
#include <nlohmann/json.hpp>
#include "lib.hpp"
#include "game.hpp"
#include "shaders.hpp"
#include "test.hpp"
using std::cout, std::cin, std::string, nlohmann::json;
using namespace Mistical;

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow *window, json Settings);

Mistical::Key KeyClass;
Mistical::JSON jsonClass;
Mistical::Lang LangClass;
Mistical::Opengl OpenglClass;
//Mistical::Shader Shader;

int main() {
    //Console Console;
    json Settings = jsonClass.ParseJSONFile("settings.json");
    cout << Settings["abcd"] << "\n";
    
    OpenglClass.initGLFW();
    //OpenglClass.initGLAD();
    GLFWwindow* Window;
    //GLFWwindow* Window = glfwCreateWindow(Settings["window"]["width"], Settings["window"]["height"], Settings["window"]["title"].get<std::string>().c_str(), nullptr, nullptr);
    if (Settings["fullscreen"] == true) {Window = OpenglClass.createWindow(Settings["window"]["width"], Settings["window"]["height"], Settings["window"]["title"].get<std::string>().c_str(), glfwGetPrimaryMonitor(), NULL, {iconPath: Settings["window"]["icon_path"].get<std::string>().c_str()}); }
    else Window = OpenglClass.createWindow(Settings["window"]["width"], Settings["window"]["height"], Settings["window"]["title"].get<std::string>().c_str(), NULL, NULL, {iconPath: Settings["window"]["icon_path"].get<std::string>().c_str()});

    glfwMakeContextCurrent(Window);
    glfwSetFramebufferSizeCallback(Window, framebuffer_size_callback);

    gladLoadGL();
    glViewport(0, 0, Settings["window"]["width"], Settings["window"]["height"]);
    

        // build and compile our shader program
    // ------------------------------------
    // vertex shader
    unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
    glCompileShader(vertexShader);
    // check for shader compile errors
    int success;
    char infoLog[512];
    glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
    }
    // fragment shader
    unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
    glCompileShader(fragmentShader);
    // check for shader compile errors
    glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
    }
    // link shaders
    unsigned int shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    // check for linking errors
    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
    }
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    // set up vertex data (and buffer(s)) and configure vertex attributes
    // ------------------------------------------------------------------
    /*float vertices[] = {
         0.5f,  0.5f, 0.0f,  // top right
         0.5f, -0.5f, 0.0f,  // bottom right
        -0.5f, -0.5f, 0.0f,  // bottom left
        -0.5f,  0.5f, 0.0f   // top left 
    };
    unsigned int indices[] = {  // note that we start from 0!
        0, 1, 3,  // first Triangle
        1, 2, 3   // second Triangle
    };*/
    float vertices[] = {
        Settings["vertices"][0][0], Settings["vertices"][0][1], Settings["vertices"][0][2],
        Settings["vertices"][1][0], Settings["vertices"][1][1], Settings["vertices"][1][2],
        Settings["vertices"][2][0], Settings["vertices"][2][1], Settings["vertices"][2][2],
        Settings["vertices"][3][0], Settings["vertices"][3][1], Settings["vertices"][3][2]
    };
    /*float vertices[] = {
        // positions          // colors           // texture coords
        0.5f,  0.5f, 0.0f,   1.0f, 0.0f, 0.0f,   1.0f, 1.0f,   // top right
        0.5f, -0.5f, 0.0f,   0.0f, 1.0f, 0.0f,   1.0f, 0.0f,   // bottom right
        -0.5f, -0.5f, 0.0f,   0.0f, 0.0f, 1.0f,   0.0f, 0.0f,   // bottom left
        -0.5f,  0.5f, 0.0f,   1.0f, 1.0f, 0.0f,   0.0f, 1.0f    // top left 
    };*/
    unsigned int indices[] = {
        Settings["indices"][0][0], Settings["indices"][0][1], Settings["indices"][0][2],
        Settings["indices"][1][0], Settings["indices"][1][1], Settings["indices"][1][2]
    };
    unsigned int VBO, VAO, EBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);
    // bind the Vertex Array Object first, then bind and set vertex buffer(s), and then configure vertex attributes(s).
    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // note that this is allowed, the call to glVertexAttribPointer registered VBO as the vertex attribute's bound vertex buffer object so afterwards we can safely unbind
    glBindBuffer(GL_ARRAY_BUFFER, 0); 

    // remember: do NOT unbind the EBO while a VAO is active as the bound element buffer object IS stored in the VAO; keep the EBO bound.
    //glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    // You can unbind the VAO afterwards so other VAO calls won't accidentally modify this VAO, but this rarely happens. Modifying other
    // VAOs requires a call to glBindVertexArray anyways so we generally don't unbind VAOs (nor VBOs) when it's not directly necessary.
    glBindVertexArray(0); 


    // uncomment this call to draw in wireframe polygons.
    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

    LangClass.setSelectedLang(LangClass.EN_GB);

    float texCoords[] = {
        0.0f, 0.0f,  // lower-left corner  
        1.0f, 0.0f,  // lower-right corner
        0.5f, 1.0f   // top-center corner
    };
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    int width, height, nrChannels;
    unsigned char *data = stbi_load("container.jpg", &width, &height, &nrChannels, 0); 
    unsigned int texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
    stbi_image_free(data);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    //cout << "Key strings:\t" << keyStrings[32] << "\t" << keyStrings[256] << "\t" << keyStrings[348] << "ABCD\n";
    /*for (int i = 0; i < 349; i++) {
        cout << i << ":\t" << keyStrings[i] << "\n";
    }*/
    
    // render loop
    // -----------
    while (!glfwWindowShouldClose(Window)) {
        Settings = jsonClass.ParseJSONFile("settings.json");
        // input
        // -----
        processInput(Window, Settings);
        
        // std::cout << "is A pressed\t   " << KeyClass.wasPressed(Window, GLFW_KEY_A) << "\n";
        // std::cout << "is A released\t   " << KeyClass.wasReleased(Window, GLFW_KEY_A) << "\n";
        // std::cout << "is B pressed\t   " << KeyClass.wasPressed(Window, GLFW_KEY_B) << "\n";
        // std::cout << "is B released\t   " << KeyClass.wasReleased(Window, GLFW_KEY_B) << "\n";
        // std::cout << "is C pressed\t   " << KeyClass.wasPressed(Window, GLFW_KEY_C) << "\n";
        // std::cout << "is C released\t   " << KeyClass.wasReleased(Window, GLFW_KEY_C) << "\n";


        // render
        // ------
        glClearColor(Settings["colors"][0], Settings["colors"][1], Settings["colors"][2], Settings["colors"][3]);
        glClear(GL_COLOR_BUFFER_BIT);

        // draw our first triangle
        glUseProgram(shaderProgram);
        glBindVertexArray(VAO); // seeing as we only have a single VAO there's no need to bind it every time, but we'll do so to keep things a bit more organized
        //glDrawArrays(GL_TRIANGLES, 0, 6);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        // glBindVertexArray(0); // no need to unbind it every time 
 
        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        // -------------------------------------------------------------------------------
        glfwSwapBuffers(Window);
        glfwPollEvents();
    }
    // optional: de-allocate all resources once they've outlived their purpose:
    // ------------------------------------------------------------------------
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);
    glDeleteProgram(shaderProgram);

    /*while (!glfwWindowShouldClose(Window)) {
        
        glClearColor(Settings["colors"][0], Settings["colors"][1], Settings["colors"][2], Settings["colors"][3]);
        glfwPollEvents();
        // glClearColor(0.1f, 0.1f, 0.15f, 1.0f);
        // glClear(GL_COLOR_BUFFER_BIT);

        glClear(GL_COLOR_BUFFER_BIT);
        glfwSwapBuffers(Window);
    }*/

    glfwTerminate();
    return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
bool a_pressed = false;
void processInput(GLFWwindow *window, json Settings) {
    if (KeyClass.isPressed(window, Settings["keys"]["close_window"])) {glfwSetWindowShouldClose(window, true);}
    // if (KeyClass.isPressed(window, GLFW_KEY_A) && a_pressed == false) {
    //     cout << "A pressed\n";
    //     a_pressed = true;
    // }
    // if (KeyClass.isReleased(window, GLFW_KEY_A) && a_pressed == true) {
    //     cout << "A released\n";
    //     a_pressed = false;
    // }
    // if (KeyClass.isRepeating(window, GLFW_KEY_A)) {cout << "A is repeating\n";}

    // if (KeyClass.wasPressed(window, GLFW_KEY_A)) { cout << "A was pressed!\n"; }
    // if (KeyClass.wasReleased(window, GLFW_KEY_A)) { cout << "A was released!\n"; }
    // if (KeyClass.wasPressed(window, GLFW_KEY_B)) { cout << "B was pressed!\n"; }
    // if (KeyClass.wasReleased(window, GLFW_KEY_B)) { cout << "B was released!\n"; }
    // if (KeyClass.wasPressed(window, GLFW_KEY_C)) { cout << "C was pressed!\n"; }
    // if (KeyClass.wasReleased(window, GLFW_KEY_C)) { cout << "C was released!\n"; }

    for (int i = 0; i < 349; i++) {
        glfwPollEvents();
        if (KeyClass.wasPressed(window, i)) {
            cout << keyStrings[i] << "\t was pressed\n";
        }
        glfwPollEvents();
        if (KeyClass.wasReleased(window, i)) {
            cout << keyStrings[i] << "\t was released\n";
        }
        //cout << i << ":\t " << keyStrings[i] << "\n";
    } // TODO: FIX (only "Pressed" ones are shown)
}



// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}