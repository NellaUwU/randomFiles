#define ABCD
#define STB_IMAGE_IMPLEMENTATION
#include <iostream>
#include <chrono>
#include <ctime>
#include <time.h>
#include <iomanip>
#include <mutex>
#include <string>
#include <windows.h>
#include <chrono>
#include <thread>
#include <algorithm>
#include <format>
#include <unordered_map>
#include <memory>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <stb/stb.h>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <fstream>
#include <sstream>
#include <nlohmann/json.hpp>
#include "lib.hpp"
#include "game.hpp"
using std::cout, std::cin, std::string, nlohmann::json;
using namespace Mistical;

//TODO: switch the directions in from  and to - (rn: y, x, in: x, y)

#define NULLISH(ptr, fallback) ((ptr) ? *(ptr) : (fallback))
void windowResizeCb(GLFWwindow* window, int width, int height);

int main() {
    int ia = 1, jb = 8;
    // Console::trace("asddasdad %d; adada %d", ia, jb);
    // Console::log("asddasdad %d; adada %d", ia, jb);
    // Console::warn("asddasdad %d; adada %d", ia, jb);
    // Console::error("asddasdad %d; adada %d", ia, jb);
    // Console::criticalError("asddasdad %d; adada %d", ia, jb);
    // Console::debug("asddasdad %d; adada %d", ia, jb);
    JSON json;
    const nlohmann::json settings = json.ParseJSONFile(".settings.json");
    Console::trace("Initialising OpenGL and GLFW");
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    Console::trace("Creating window \"mainWindow\"");
    Window mainWindow;
    mainWindow.init(settings["window"]["width"].get<int>(), settings["window"]["height"].get<int>(), settings["window"]["title"].get<std::string>().c_str()); 
    glfwMakeContextCurrent(mainWindow.window);
    mainWindow.setSizeCallback(windowResizeCb);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        Console::criticalError("Failed to initialize GLAD");
        return -1;
    }
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glViewport(0, 0, mainWindow.width, mainWindow.height);

    Shader shader(
        settings["shaders"]["vert"].get<std::string>().c_str(),
        settings["shaders"]["frag"].get<std::string>().c_str()
    );
    Mistical::Tile::setShader(&shader);
    // Console::log("Tile - h: %d, w: %d", Mistical::Tile::tileHeight, Mistical::Tile::tileHeight);
    // //std::cout << mainWindow.getSize() << "\n";
    // Console::log("H: %d", mainWindow.getHeight());
    // Console::log("W: %d", mainWindow.getWidth());
    // Console::log("h: %f", static_cast<float>(1.0f / Mistical::Tile::tilesHeight));
    // Console::log("w: %f", static_cast<float>(1.0f / Mistical::Tile::tilesWidth));
    Mistical::Tile::tileHeight = 1.0f / Mistical::Tile::tilesHeight; //mainWindow.getHeight()
    Mistical::Tile::tileWidth = 1.0f / Mistical::Tile::tilesWidth; //mainWindow.getWidth()
    //std::cout << settings["anim_path"].get<std::string>().c_str() << "\n";
    Tile testTile(settings["tile_path"].get<std::string>().c_str(),
                    settings["tile"]["x"].get<float>(),
                    settings["tile"]["y"].get<float>());
    Room testRoom(settings["room"].get<std::string>().c_str());
    AnimatedSprite testAnim;
    testAnim.loadFromPath(settings["anim_path"].get<std::string>().c_str(), &shader);
    shader.use();
    shader.setInt(settings["textures"]["grass_name"], settings["int"]);
    const char* abcd[1] = {settings["icon"].get<std::string>().c_str()};

    while (!mainWindow.shouldClose()) {
        if (mainWindow.input.key.wasPressed(GLFW_KEY_A)) {
            mainWindow.setTitle("Ur mum lol");
            mainWindow.setIconsFromPath(abcd, 1);
            mainWindow.setSizeLimits(256, 256, 1024, 1024);
            mainWindow.setMinimalizationCallback(miniCb);
        }
        if (mainWindow.input.key.wasPressed(GLFW_KEY_Q)) {
            Console::debug("Size of tiles is %d", testRoom.getTilesSize());
            Console::debug("Size of a tile is %f x %f", Tile::tileHeight, Tile::tileWidth);
        }
        mainWindow.swapBuffers();
        glfwPollEvents();
        glClear(GL_COLOR_BUFFER_BIT);
        Time::update();

        shader.use();
        testRoom.updateTiles();
        testTile.draw();
        testAnim.draw();
        if (mainWindow.input.key.wasPressed(GLFW_KEY_W)) {
            Console::debug("Draw calls: %d, Texture binds: %d", Sprite::drawCalls, Texture::textureBinds);
            Console::debug("FPS: %f, DeltaTime: %f, UDT: %f", Time::fps(), Time::deltaTime(), Time::unscaledDeltaTime());
        }
        Sprite::drawCalls = 0;
        Texture::textureBinds = 0;


        glDrawElements(
            GL_TRIANGLES,
            6,
            GL_UNSIGNED_INT,
            0
        );
    }

    glfwTerminate();
    return 0;
}

void windowResizeCb(GLFWwindow* window, int width, int height) {
    //Console::trace("Window size changed! the new size is %d x %d", width, height);
}


/*
float vertices[] =
    {
        // position       // tex coords

        -0.5f, -0.5f, 0.0f, 0.0f, 0.0f,
        0.5f, -0.5f, 0.0f, 1.0f, 0.0f,
        0.5f,  0.5f, 0.0f, 1.0f, 1.0f,
        -0.5f,  0.5f, 0.0f, 0.0f, 1.0f
    };

    unsigned int indices[] =
    {
        0,1,2,
        2,3,0
    };

    GLuint VAO, VBO, EBO;
    
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(
        GL_ARRAY_BUFFER,
        sizeof(vertices),
        vertices,
        GL_STATIC_DRAW
    );

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(
        GL_ELEMENT_ARRAY_BUFFER,
        sizeof(indices),
        indices,
        GL_STATIC_DRAW
    );

    glVertexAttribPointer(
        0,
        3,
        GL_FLOAT,
        GL_FALSE,
        5 * sizeof(float),
        (void*)0
    );

    glEnableVertexAttribArray(0);

    glVertexAttribPointer(
        1,
        2,
        GL_FLOAT,
        GL_FALSE,
        5 * sizeof(float),
        (void*)(3 * sizeof(float))
    );

    glEnableVertexAttribArray(1);
*/

/*

    Sprite grass(settings["textures"]["grass"].get<std::string>().c_str());
    Sprite stone(settings["textures"]["stone"].get<std::string>().c_str());
    AnimatedSprite anim({"icon.png", "icon-diamond.png"}, 2, &shader, 0.5f, {1.5f, -1.0f});
    anim.position(0.0f, 0.0f);
    anim.setRotation(90.0f);
    AnimatedSprite testAnim;
    testAnim.loadFromPath(settings["anim_path"].get<std::string>().c_str(), &shader);
*/

    //std::cout << settings["tile_path"].get<std::string>().c_str() << "\n";
    //grass.position(0.5f, 0.0f);

    // grass.load(settings["textures"]["grass"].get<std::string>().c_str());
    // stone.load(settings["textures"]["stone"].get<std::string>().c_str());
    //std::cout << grass.getTextureWidth(0) << "x" << grass.getTextureHeight(0) << '\n';
    //std::cout << stone.getTextureWidth(0) << "x" << stone.getTextureHeight(0) << '\n';

    
        //grass.draw(shader);
        //stone.draw(shader);
        //anim.draw();
        // grass.bind(0);
        // stone.bind(1);
        //testAnim.draw();