#ifndef ABCD
#   include <glfw3.h>
#   include <glm/glm.hpp>
#   include <stb/stb.h>
#   include <nlohmann/json.hpp>
#   include <fstream>
#   include <iostream>
#   include <glm/glm.hpp>
#   include <glm/gtc/type_ptr.hpp>
#   include <glm/gtc/matrix_transform.hpp>
#   endif
#ifdef __Mistical__
#   warning MisticalGL was already included!
#   endif
#ifndef __Mistical__
#   define __Mistical__
#   endif
#include <string>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <chrono>
#include <thread>
#include <windows.h>

namespace Mistical {
    /*class Console {
        public:
            #define TRACE(msg, ...)          _log("       ", msg, TEXT_COLOR_WHITE, ##__VA_ARGS__);
            #define LOG(msg, ...)            _log("LOG:   ", msg, TEXT_COLOR_WHITE, ##__VA_ARGS__);
            #define WARN(msg, ...)           _log("WARN:  ", msg, TEXT_COLOR_YELLOW, ##__VA_ARGS__);
            #define ERROR(msg, ...)          _log("ERROR: ", msg, TEXT_COLOR_BRIGHT_RED, ##__VA_ARGS__);
            #define CRITICAL_ERROR(msg, ...) _log("CRIT:  ", msg, TEXT_COLOR_RED, ##__VA_ARGS__);
        private:
            enum TextColor {
                TEXT_COLOR_BLACK,   TEXT_COLOR_BRIGHT_BLACK,
                TEXT_COLOR_RED,     TEXT_COLOR_BRIGHT_RED,
                TEXT_COLOR_GREEN,   TEXT_COLOR_BRIGHT_GREEN,
                TEXT_COLOR_YELLOW,  TEXT_COLOR_BRIGHT_YELLOW,
                TEXT_COLOR_BLUE,    TEXT_COLOR_BRIGHT_BLUE,
                TEXT_COLOR_MAGENTA, TEXT_COLOR_BRIGHT_MAGENTA,
                TEXT_COLOR_CYAN,    TEXT_COLOR_BRIGHT_CYAN,
                TEXT_COLOR_WHITE,   TEXT_COLOR_BRIGHT_WHITE,
                TEXT_COLOR_COUNT 
            };
            template <typename ...Args>
            void _log(const char* prefix, const char* msg, TextColor textColor, Args... args) {
                std::cout << msg << args;
            }
    };*/
    class Opengl {
        public:
            struct WindowSettings{
                bool focused;
                bool iconifined;
                bool resizeable;
                bool visible;
                bool decorated;
                bool autoIconify;
                bool floating;
                bool maximazed;
                bool centerCursor;
                std::string iconPath;
            };
            void initGLFW(bool initGLFW = true, int verMinor = 3, int verMajor = 3) {
                if (initGLFW == true) {
                    glfwInit();
                }
                glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, verMinor);
                glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, verMajor);
                glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
            }

            void initGLAD() {
                std::cout << "initGLAD() " << glfwGetProcAddress << "\n"; 
                if (!gladLoadGLLoader((GLADloadproc) glfwGetProcAddress)) {
                    //Console.CRITICAL_ERROR("Failed to initialize GLAD");
                    std::cout << "Failed to initialize GLAD\n";
                }
            }

            GLFWwindow* createWindow(int width, int height, const char* title, GLFWmonitor* monitor, GLFWwindow* share, WindowSettings windowSettings = {resizeable: true, iconPath: ""}) {
                GLFWwindow* res = glfwCreateWindow(width, height, title, monitor, share);
                glfwWindowHint(GLFW_RESIZABLE, windowSettings.resizeable);
                if (windowSettings.iconPath != "") {
                    GLFWimage images[1];
                    int iconWidth, iconHeight, iconChannels;
                    unsigned char* iconPixels = stbi_load(windowSettings.iconPath.c_str(), &iconWidth, &iconHeight, &iconChannels, 4);
                    images[0].width = iconWidth;
                    images[0].height = iconHeight;
                    images[0].pixels = iconPixels;
                    glfwSetWindowIcon(res, 1, images); //Set all of this to Image.load() later..
                } else {
                    glfwSetWindowIcon(res, 0, NULL);
                }
                return res;
            }
        private:
            
                //Mistical::Console Console;
    };
    class Image {
        public:
            GLFWimage load(std::string path, int req_comp = 4) {
                GLFWimage image;
                int imgWidth, imgHeight, imgComp;
                unsigned char* imgPixels = stbi_load(path.c_str(), &imgWidth, &imgHeight, &imgComp, req_comp);
                image.width = imgWidth;
                image.height = imgHeight;
                image.pixels = imgPixels;
                return image;
            }
        private:
    };
    class Key {
        #define IS_RELEASED     0
        #define IS_PRESSED      1
        #define IS_REPEATING    2
        public:
            bool isReleased(GLFWwindow* window, int key) {
                if (glfwGetKey(window, key) == GLFW_RELEASE) { return true; }
                return false;
            }
            bool isPressed(GLFWwindow* window, int key) {
                if (glfwGetKey(window, key) == GLFW_PRESS) { return true; }
                return false;
            }
            bool isRepeating(GLFWwindow* window, int key) {
                if (glfwGetKey(window, key) == GLFW_REPEAT) { return true; }
                return false;
            }
            bool wasPressed(GLFWwindow* window, int key) {
                if (glfwGetKey(window, key) == GLFW_PRESS && pressedKeys[key] == false) {
                    pressedKeys[key] = true;
                    return true;
                }
                checkKeyPress(window, key);
                return false;
            }
            bool wasReleased(GLFWwindow* window, int key) {
                if (glfwGetKey(window, key) == GLFW_RELEASE && pressedKeys[key] == true) {
                    pressedKeys[key] = false;
                    return true;
                }
                checkKeyPress(window, key);
                return false;
            }
        private:
            bool pressedKeys[349];
            void checkKeyPress(GLFWwindow* window, int key) {
                if (glfwGetKey(window, key) == GLFW_PRESS) {
                    pressedKeys[key] = true;
                    return;
                }
                pressedKeys[key] = false;
            }
    };
    class JSON {
        public:
        nlohmann::json ParseJSONFile(std::string filePath) {
            std::ifstream JSONFile(filePath);
            if (!JSONFile.is_open()) {
                return {{"result", NULL}};
            }
            nlohmann::json returnJSON;
            JSONFile >> returnJSON;
            return returnJSON;
        }
        private:
        
    };
    class Lang {
        public:
            enum Langs {
                CS_CZ,
                EN_AU,
                EN_GB,
                EN_US,
                JA_JP
            };
            std::string getTranslationKey(std::string key) {
                nlohmann::json langJSON = getSelectedLangJSON();
                return langJSON[key].get<std::string>().c_str();
            }
            void setSelectedLang(enum Langs lang) {
                selectedLang = lang;
                selectedLangJSON = jsonClass.ParseJSONFile(langsFilepath + langNames[lang] + ".json");
            }
            Langs getSelectedLang() {
                return selectedLang;
            }
            nlohmann::json getSelectedLangJSON() {
                return selectedLangJSON;
            }
        private:
            Langs selectedLang;
            nlohmann::json selectedLangJSON;
            const std::string langsFilepath = "./data/lang/";
            Mistical::JSON jsonClass;
            const char* langNames[5] = {
                "CS_CZ",
                "EN_AU",
                "EN_GB",
                "EN_US",
                "JA_JP"
            };
    };
    class ColorClass {
        public:
        private:
    };
    class Window {
        public:
            int pos[2];
            int height = 512;
            int width = 512;
            const char* title = "Window";
            GLFWimage* icons;
            GLFWmonitor* monitor = NULL;
            GLFWwindow* share = NULL;
            GLFWwindow* window;
            double cursorPos[2] = {0, 0};
            int cursorMode = GLFW_CURSOR;
            void init();
            void init(int pWidth, int pHeight, const char* pTitle);
            void init(int pWidth, int pHeight, const char* pTitle, GLFWimage* pIcons);
            void init(int pWidth, int pHeight, const char* pTitle, GLFWmonitor* pMonitor, GLFWwindow* pShare);
            void init(int pWidth, int pHeight, const char* pTitle, GLFWimage* pIcons, GLFWmonitor* pMonitor, GLFWwindow* pShare);
            void update();
            void swapBuffers();
            void moveTo(int x, int y);
            void minimalize();
            void unMinimalize();
            void hide();
            void show();
            void focus();
            void requestAttention();
            void setPositionCallback(GLFWwindowposfun callback);
            void setSizeCallback(GLFWwindowsizefun callback);
            void setMinimalizationCallback(GLFWwindowiconifyfun callback);
            void setFocusCallback(GLFWwindowfocusfun callback);
            void setCloseCallback(GLFWwindowclosefun callback);
            void setCursorPosCallback(GLFWcursorposfun callback);
            void setIconsFromPath(const char** path, int count);
            void setAttribute(int attrib, int value);
            void setPos(int x, int y);
            void setSize(int w, int h);
            void setSizeLimits(int minW, int minH, int maxW, int maxH);
            void setCursor(int cursor);
            void setCursor(int cursor, int mode);
            void removeSizeLimits();
            void setTitle(const char* t);
            int getAttribute(int attribute);
            int* getPos();
            int* getSize();
            const char* getTitle();
            bool shouldClose();
            void destroy();
            void close();
            class WindowInput {
                public:
                    WindowInput(Window& w) : window(w), key(w), mouse(w) {}
                    class WindowInputKey {
                        public:
                            WindowInputKey(Window& w) : window(w) {}
                            bool isReleased(int key);
                            bool isPressed(int key);
                            bool isRepeating(int key);
                            bool wasPressed(int key);
                            bool wasReleased(int key);
                        private:
                            Window& window;
                            void checkKeyPress(int key);
                            bool pressedKeys[349];
                    };
                    class WindowInputMouse {
                        public:
                            WindowInputMouse(Window& w) : window(w) {}
                            bool isReleased(int btn);
                            bool isPressed(int btn);
                            bool wasReleased(int btn);
                            bool wasPressed(int btn);
                        private:
                            Window& window;
                    };
                    WindowInputKey key;
                    WindowInputMouse mouse;
                private:
                    Window& window;
            };

            WindowInput input;
            Window() : input(*this) {}
        private:
            bool fullScreen = false;
    };
    void Window::init() {
        window = glfwCreateWindow(width, height, title, monitor, share);
    }
    void Window::init(int pWidth, int pHeight, const char* pTitle) {
        height = pHeight;
        width = pWidth;
        title = pTitle;
        window = glfwCreateWindow(width, height, title, monitor, share);
    }
    void Window::init(int pWidth, int pHeight, const char* pTitle, GLFWimage* pIcons) {
                height = pHeight;
                width = pWidth;
                title = pTitle;
                icons = pIcons;
                window = glfwCreateWindow(width, height, title, monitor, share);
                glfwSetWindowIcon(window, sizeof icons / sizeof icons[0], icons);
            }
    void Window::init(int pWidth, int pHeight, const char* pTitle, GLFWmonitor* pMonitor, GLFWwindow* pShare) {
        height = pHeight;
        width = pWidth;
        title = pTitle;
        monitor = pMonitor;
        share = pShare;
        window = glfwCreateWindow(width, height, title, monitor, share);
    }
    void Window::init(int pWidth, int pHeight, const char* pTitle, GLFWimage* pIcons, GLFWmonitor* pMonitor, GLFWwindow* pShare) {
        height = pHeight;
        width = pWidth;
        title = pTitle;
        monitor = pMonitor;
        share = pShare;
        icons = pIcons;
        window = glfwCreateWindow(width, height, title, monitor, share);
        glfwSetWindowIcon(window, sizeof icons / sizeof icons[0], icons);
    }
    void Window::update() {
        glfwSetWindowPos(window, pos[0], pos[1]);
        glfwSetWindowSize(window, width, height);
        glfwSetWindowTitle(window, title);
    }
    void Window::swapBuffers() {
        glfwSwapBuffers(window);
    }
    void Window::moveTo(int x, int y) {
        pos[0] = x;
        pos[1] = y;
        glfwSetWindowPos(window, pos[0], pos[1]);
    }
    void Window::minimalize() {
        glfwIconifyWindow(window);
    }
    void Window::unMinimalize() {
        glfwRestoreWindow(window);
    }
    void Window::hide() {
        glfwHideWindow(window);
    }
    void Window::show() {
        glfwShowWindow(window);
    }
    void Window::focus() {
        glfwFocusWindow(window);
    }
    void Window::requestAttention() {
        glfwRequestWindowAttention(window);
    }
    void Window::setPositionCallback(GLFWwindowposfun callback) { //! @brief Runs the specified function on change of the position of the window `void window_pos_callback(GLFWwindow* window, int xpos, int ypos) {}`
        glfwSetWindowPosCallback(window, callback);
    }
    void Window::setSizeCallback(GLFWwindowsizefun callback) { //! @brief Runs the specified function on change of the size of the window `void window_size_callback(GLFWwindow* window, int width, int height) {}`
        glfwSetWindowSizeCallback(window, callback);
    }
    void Window::setMinimalizationCallback(GLFWwindowiconifyfun callback) { //! @brief Runs the specified function on the minimalization of the window `void window_iconify_callback(GLFWwindow* window, int iconified) {}`
        glfwSetWindowIconifyCallback(window, callback);
    }
    void Window::setFocusCallback(GLFWwindowfocusfun callback) { //! @brief Runs the specified function on window focus `void window_focus_callback(GLFWwindow* window, int focused) {}`
        glfwSetWindowFocusCallback(window, callback);
    }
    void Window::setCloseCallback(GLFWwindowclosefun callback) { //! @brief Runs the specified function on window closure `void window_close_callback(GLFWwindow* window) {}`
        glfwSetWindowCloseCallback(window, callback);
    }
    void Window::setIconsFromPath(const char** path, int count) {
        GLFWimage* images = new GLFWimage[count];
        for (int i = 0; i < count; i++) {
            images[i].pixels = stbi_load(path[i], &images[i].width, &images[i].height, nullptr, 4);
        }
        icons = images;
        glfwSetWindowIcon(window, count, images);
        for (int i = 0; i < count; i++) {
            if (images[i].pixels) {
                stbi_image_free(images[i].pixels);
            }
        }
        delete[] images;
    }
    void Window::setAttribute(int attrib, int value) {
        glfwSetWindowAttrib(window, attrib, value);
    }
    void Window::setPos(int x, int y) {
        glfwSetWindowPos(window, x, y);
    }
    void Window::setSize(int w, int h) {
        glfwSetWindowSize(window, w, h);
    }
    void Window::setSizeLimits(int minW, int minH, int maxW, int maxH) {
        glfwSetWindowSizeLimits(window, minW, minH, maxW, maxH);
    }
    void Window::setCursor(int cursor) {
        glfwSetInputMode(window, cursorMode, cursor);
    }
    void Window::setCursor(int cursor, int mode) {
        mode = cursor;
        glfwSetInputMode(window, cursorMode, cursor);
    }
    void Window::removeSizeLimits() {
        glfwSetWindowSizeLimits(window, GLFW_DONT_CARE, GLFW_DONT_CARE, GLFW_DONT_CARE, GLFW_DONT_CARE);
    }
    void Window::setTitle(const char* t) {
        glfwSetWindowTitle(window, t);
    }
    int Window::getAttribute(int attribute) {
        return glfwGetWindowAttrib(window, attribute);
    }
    int* Window::getPos() {
        int pos[2];
        glfwGetWindowPos(window, &pos[0], &pos[1]);
        return pos;
    }
    int* Window::getSize() {
        int size[2];
        glfwGetWindowSize(window, &size[0], &size[1]);
        return size;
    }
    const char* Window::getTitle() {
        return glfwGetWindowTitle(window);
    }
    bool Window::shouldClose() {
        return glfwWindowShouldClose(window);
    }
    void Window::destroy() {
        glfwDestroyWindow(window);
    }
    void Window::close() {
        glfwDestroyWindow(window);
    }
    bool Window::WindowInput::WindowInputKey::isReleased(int key) {
        if (glfwGetKey(window.window, key) == GLFW_RELEASE) { return true; }
        return false;
    }
    bool Window::WindowInput::WindowInputKey::isPressed(int key) {
        if (glfwGetKey(window.window, key) == GLFW_PRESS) { return true; }
        return false;
    }
    bool Window::WindowInput::WindowInputKey::isRepeating(int key) {
        if (glfwGetKey(window.window, key) == GLFW_REPEAT) { return true; }
        return false;
    }
    bool Window::WindowInput::WindowInputKey::wasPressed(int key) {
        if (glfwGetKey(window.window, key) == GLFW_PRESS && pressedKeys[key] == false) {
            pressedKeys[key] = true;
            return true;
        }
        checkKeyPress(key);
        return false;
    }
    bool Window::WindowInput::WindowInputKey::wasReleased(int key) {
        if (glfwGetKey(window.window, key) == GLFW_RELEASE && pressedKeys[key] == true) {
            pressedKeys[key] = false;
            return true;
        }
        checkKeyPress(key);
        return false;
    }
    void Window::WindowInput::WindowInputKey::checkKeyPress(int key) {
        if (glfwGetKey(window.window, key) == GLFW_PRESS) {
            pressedKeys[key] = true;
            return;
        }
        pressedKeys[key] = false;
    }

    class Shader {
        public:
            GLuint ID;
            Shader(const char* vertexPath, const char* fragmentPath);
            void use();
            void setInt(const std::string& name, int value) const;
            void setMat4(const std::string& name, const glm::mat4& matrix) const;
    };
    Shader::Shader(const char* vertexPath, const char* fragmentPath) {
        std::ifstream vFile(vertexPath);
        std::ifstream fFile(fragmentPath);
        std::stringstream vStream;
        std::stringstream fStream;

        vStream << vFile.rdbuf();
        fStream << fFile.rdbuf();

        std::string vString = vStream.str();
        std::string fString = fStream.str();
        const char* vCode = vString.c_str();
        const char* fCode = fString.c_str();

        GLuint vertex = glCreateShader(GL_VERTEX_SHADER);
        glShaderSource(vertex, 1, &vCode, nullptr);
        glCompileShader(vertex);

        GLuint fragment = glCreateShader(GL_FRAGMENT_SHADER);
        glShaderSource(fragment, 1, &fCode, nullptr);
        glCompileShader(fragment);

        ID = glCreateProgram();

        glAttachShader(ID, vertex);
        glAttachShader(ID, fragment);
        glLinkProgram(ID);

        glDeleteShader(vertex);
        glDeleteShader(fragment);
    }
    void Shader::use() {
        glUseProgram(ID);
    }
    void Shader::setInt(const std::string& name, int value) const {
        glUniform1i( glGetUniformLocation(ID, name.c_str()), value );
    }
    void Shader::setMat4(const std::string& name, const glm::mat4& matrix) const {
        glUniformMatrix4fv(
            glGetUniformLocation(ID, name.c_str()),
            1,
            GL_FALSE,
            glm::value_ptr(matrix)
        );
    }

    enum class TextureFlip {
        None,
        X,
        Y,
        XY
    };
    enum class TextureRotation {
        Deg0,
        Deg90,
        Deg180,
        Deg270
    };
    class Texture {
        private:
        GLuint textureID;
        int width;
        int height;
        int channels;
        TextureFlip flipState;
        TextureRotation rotationState;
        public:
        Texture();
        ~Texture();
        bool load(const std::string& path);
        void bind(unsigned int slot = 0) const;
        void unbind() const;
        void flip(TextureFlip flip);
        void rotate(TextureRotation rotation);
        GLuint getID() const;
        int getWidth() const;
        int getHeight() const;
        TextureFlip getFlip() const;
        TextureRotation getRotation() const;
    };
    Texture::Texture() {
        textureID = 0;
        width = 0;
        height = 0;
        channels = 0;
        flipState = TextureFlip::None;
        rotationState = TextureRotation::Deg0;
    }
    Texture::~Texture() {
        if(textureID) glDeleteTextures(1, &textureID);
    }
    bool Texture::load(const std::string& path) {
        stbi_set_flip_vertically_on_load(true);
        unsigned char* data =
            stbi_load(
                path.c_str(),
                &width,
                &height,
                &channels,
                0
            );
        if(!data) return false;
        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexParameteri(
            GL_TEXTURE_2D,
            GL_TEXTURE_WRAP_S,
            GL_REPEAT
        );

        glTexParameteri(
            GL_TEXTURE_2D,
            GL_TEXTURE_WRAP_T,
            GL_REPEAT
        );

        glTexParameteri(
            GL_TEXTURE_2D,
            GL_TEXTURE_MIN_FILTER,
            GL_NEAREST
        );

        glTexParameteri(
            GL_TEXTURE_2D,
            GL_TEXTURE_MAG_FILTER,
            GL_NEAREST
        );

        GLenum format = GL_RGB;

        if(channels == 1)       format = GL_RED;
        else if(channels == 3)  format = GL_RGB;
        else if(channels == 4)  format = GL_RGBA;

        glTexImage2D(
            GL_TEXTURE_2D,
            0,
            format,
            width,
            height,
            0,
            format,
            GL_UNSIGNED_BYTE,
            data
        );

        glGenerateMipmap(GL_TEXTURE_2D);
        stbi_image_free(data);
        return true;
    }
    void Texture::bind(unsigned int slot) const {
        glActiveTexture(GL_TEXTURE0 + slot);
        glBindTexture(GL_TEXTURE_2D, textureID);
    }
    void Texture::unbind() const {
        glBindTexture(GL_TEXTURE_2D, 0);
    }
    void Texture::flip(TextureFlip flip) {
        flipState = flip;
    }
    void Texture::rotate(TextureRotation rotation) {
        rotationState = rotation;
    }
    GLuint Texture::getID() const {
        return textureID;
    }
    int Texture::getWidth() const {
        return width;
    }
    int Texture::getHeight() const {
        return height;
    }
    TextureFlip Texture::getFlip() const {
        return flipState;
    }
    TextureRotation Texture::getRotation() const {
        return rotationState;
    }

    class Sprite {
        public:
            Sprite(const char* path);
            float getSpriteWidth() const {return getSpriteWidth();}
            float getSpriteHeight() const {return getSpriteHeight();}
            int getTextureHeight(int frame) {return frames[frame].texture.getHeight();}
            int getTextureWidth(int frame) {return frames[frame].texture.getWidth();}
            void draw(Shader shader) {frames[0].draw(shader);}
        private:
            class SpriteObj {
                public:
                    SpriteObj(const char*& texturePath);
                    void position(float px, float py);
                    void size(float pw, float ph);
                    void rotate(TextureRotation pRotation);
                    void flip(TextureFlip pFlip);
                    void draw(Shader& shader);
                    float getSpriteWidth() const;
                    float getSpriteHeight() const;
                    int getTextureHeight();
                    int getTextureWidth();
                    TextureFlip getFlip() const;
                    TextureRotation getRotation() const;
                    Texture texture;
                private:
                    float x, y;
                    float w, h;
                    TextureRotation rotation;
                    TextureFlip flipState;
                    static GLuint VAO, VBO, EBO;
                    static bool initialized;
                    static void initQuad();
            };
            SpriteObj* frames;
            float timeBetweenFrames = 1;
    };
    Sprite::Sprite(const char* path) {
        nlohmann::json json;
        try {
            json = {}; //loadjson
        } catch (std::exception&) {
            //throw exception
            return;
        }
        for (int i = 0; i < json["frames"]; i++) {

        }
    }
    void Sprite::SpriteObj::position(float px, float py) {
        x = px;
        y = py;
    }
    void Sprite::SpriteObj::size(float pw, float ph) {
        w = pw;
        h = ph;
    }
    void Sprite::SpriteObj::rotate(TextureRotation pRotation) {
        rotation = pRotation;
    }
    void Sprite::SpriteObj::flip(TextureFlip pFlip) {
        flipState = pFlip;
    }
    void Sprite::SpriteObj::draw(Shader& shader) {
        glm::mat4 model = glm::mat4(1.0f);

        model = glm::translate(model, glm::vec3(x, y, 0.0f));
        switch (rotation) {
            case TextureRotation::Deg0:
                model = glm::rotate(model, glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
                break;
            case TextureRotation::Deg90:
                model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
                break;
            case TextureRotation::Deg180:
                model = glm::rotate(model, glm::radians(180.0f), glm::vec3(0.0f, 0.0f, 1.0f));
                break;
            case TextureRotation::Deg270:
                model = glm::rotate(model, glm::radians(270.0f), glm::vec3(0.0f, 0.0f, 1.0f));
                break;
        }
        model = glm::scale(model, glm::vec3(w, h, 1.0f));

        shader.setMat4("model", model);

        texture.bind(0);
        shader.setInt("tex", 0);

        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
    }
    void Sprite::SpriteObj::initQuad() {
        float vertices[] = {
            // pos         // tex
            -0.5f, -0.5f,  0.0f, 0.0f,
            0.5f, -0.5f,  1.0f, 0.0f,
            0.5f,  0.5f,  1.0f, 1.0f,
            -0.5f,  0.5f,  0.0f, 1.0f
        };

        unsigned int indices[] = {
            0,1,2,
            2,3,0
        };

        glGenVertexArrays(1, &VAO);
        glGenBuffers(1, &VBO);
        glGenBuffers(1, &EBO);

        glBindVertexArray(VAO);

        glBindBuffer(GL_ARRAY_BUFFER, VBO);
        glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

        glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
        glEnableVertexAttribArray(0);

        glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
        glEnableVertexAttribArray(1);

        glBindVertexArray(0);

        initialized = true;
    }
    GLuint Sprite::SpriteObj::VAO = 0;
    GLuint Sprite::SpriteObj::VBO = 0;
    GLuint Sprite::SpriteObj::EBO = 0;
    bool Sprite::SpriteObj::initialized = false;
    Sprite::SpriteObj::SpriteObj(const char*& texturePath) {
        if (!initialized) initQuad();

        texture.load(texturePath);

        x = y = 0.0f;
        w = h = 1.0f;
        rotation = TextureRotation::Deg0;
        flipState = TextureFlip::None;
    }
    float Sprite::SpriteObj::getSpriteHeight() const {
        return h;
    }
    float Sprite::SpriteObj::getSpriteWidth() const {
        return w;
    }
    int Sprite::SpriteObj::getTextureHeight() {
        return texture.getHeight();
    }
    int Sprite::SpriteObj::getTextureWidth() {
        return texture.getWidth();
    }
    TextureFlip Sprite::SpriteObj::getFlip() const {
        return flipState;
    }
    TextureRotation Sprite::SpriteObj::getRotation() const {
        return rotation;
    }

    class Sound {};

    struct MusicSection {
        const char* id = "";
        float start = 0;
        float lenght = 1;
    };
    class Music {
        public:
            MusicSection* load(const char* path);
            void nextSection();
            void previousSection();
            int getActiveSection();
        private:
            int section = 0;
            MusicSection* sections;
    };
    MusicSection* Music::load(const char* path) {
        nlohmann::json json;
        MusicSection* result;
        std::string ids = " ";
        try {
            json = {}; //load from path
        } catch (std::exception&) {}
        for (int i = 0; i < json["sections"].size(); i++) {
            if (!json["sections"][i].contains("id")) {
                //throw exception
                return NULL;
            }
            if (!json["sections"][i].contains("start")) {
                //throw exception
                return NULL;
            }
            if (ids.find(" " + json["sections"][i]["id"].get<std::string>() + " ") != std::string::npos) {
                //throw exception
                return NULL;
            }
            result[i] = {
                json["sections"][i]["id"].get<std::string>().c_str(),
                json["sections"][i].value("start", 0.0f),
                json["sections"][i].contains("length")
                    ? json["sections"][i]["length"].get<float>()
                    : i + 1 < json["sections"].size()
                        ? json["sections"][i + 1]["start"].get<float>() - json["sections"][i]["start"].get<float>()
                        : json["length"].get<float>()
            };
            ids.append(json["sections"][i]["id"].get<std::string>() + " ");
        }
        return result;
    }

    struct ObjectIdentifier {
        const char* Namespace;
        const char* Id;
    };

    

    enum class TileSetSizes {
        SimpleTile,
        ThreeByThree,
        FiveByFive
    };
    enum class TileSetTypes {
        BackGround,
        Ground,
        ForeGround
    };
    class TileSet {
        public:
            TileSet(ObjectIdentifier id, const char* assetPath);
        private:
            TileSetTypes layer;
            TileSetSizes size;
            const static int gridWidth = 40;
            const static int gridHeigth = 23;
    };
    TileSet::TileSet(ObjectIdentifier id, const char* assetsPath) {}

    class Tile {

    };

  

}

Mistical::Window testWindow;
void test() {
    testWindow.init(1, 2, "title");
    testWindow.init();
}
    // void setIconsFromPath(const char** path) {
    //     GLFWimage* images;
    //     for (int i = 0; i < sizeof path / sizeof path[0]; i++) {
    //         images[i].pixels = stbi_load(path[i], &images[i].width, &images[i].height, 0, 4);
    //     }
    //     icons = images;
    //     glfwSetWindowIcon(window, sizeof icons / sizeof icons[0], icons);
    //     for (int i = 0; i < sizeof path / sizeof path[0]; i++) {
    //         stbi_image_free(images[i].pixels);
    //     }
    // }
enum timeUnits {
    nanoSeconds,
    microSeconds,
    miliSeconds,
    seconds,
    minutes,
    hours
};
void sleep(unsigned int time, timeUnits unit = miliSeconds) {
    switch (unit) {
        case nanoSeconds:   std::this_thread::sleep_for(std::chrono::nanoseconds(time));
        case microSeconds:  std::this_thread::sleep_for(std::chrono::microseconds(time));
        case miliSeconds:   std::this_thread::sleep_for(std::chrono::milliseconds(time));
        case seconds:       std::this_thread::sleep_for(std::chrono::seconds(time));
        case minutes:       std::this_thread::sleep_for(std::chrono::minutes(time));
        case hours:         std::this_thread::sleep_for(std::chrono::hours(time));
    }
}


void miniCb(GLFWwindow* window, int iconified) {
    if (iconified == GLFW_TRUE) {
        glfwRequestWindowAttention(window);
    }
}

const char* keyStrings[349] = {
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "GLFW_KEY_SPACE",
    "",
    "",
    "",
    "",
    "",
    "",
    "GLFW_KEY_APOSTROPHE",           /* ' */
    "",
    "",
    "",
    "",
    "GLFW_KEY_COMMA",                /* , */
    "GLFW_KEY_MINUS",                /* - */
    "GLFW_KEY_PERIOD",               /* . */
    "GLFW_KEY_SLASH",                /* / */
    "GLFW_KEY_0",
    "GLFW_KEY_1",
    "GLFW_KEY_2",
    "GLFW_KEY_3",
    "GLFW_KEY_4",
    "GLFW_KEY_5",
    "GLFW_KEY_6",
    "GLFW_KEY_7",
    "GLFW_KEY_8",
    "GLFW_KEY_9",
    "",
    "GLFW_KEY_SEMICOLON",            /* ; */
    "",
    "GLFW_KEY_EQUAL",                /* = */
    "",
    "",
    "",
    "GLFW_KEY_A",
    "GLFW_KEY_B",
    "GLFW_KEY_C",
    "GLFW_KEY_D",
    "GLFW_KEY_E",
    "GLFW_KEY_F",
    "GLFW_KEY_G",
    "GLFW_KEY_H",
    "GLFW_KEY_I",
    "GLFW_KEY_J",
    "GLFW_KEY_K",
    "GLFW_KEY_L",
    "GLFW_KEY_M",
    "GLFW_KEY_N",
    "GLFW_KEY_O",
    "GLFW_KEY_P",
    "GLFW_KEY_Q",
    "GLFW_KEY_R",
    "GLFW_KEY_S",
    "GLFW_KEY_T",
    "GLFW_KEY_U",
    "GLFW_KEY_V",
    "GLFW_KEY_W",
    "GLFW_KEY_X",
    "GLFW_KEY_Y",
    "GLFW_KEY_Z",
    "GLFW_KEY_LEFT_BRACKET",         /* [ */
    "GLFW_KEY_BACKSLASH",            /* \ */
    "GLFW_KEY_RIGHT_BRACKET",        /* ] */
    "",
    "",
    "GLFW_KEY_GRAVE_ACCENT",         /* ` */
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "GLFW_KEY_WORLD_1",          /* non-US #1 */
    "GLFW_KEY_WORLD_2",          /* non-US #2 */
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    //  Function keys 
    "GLFW_KEY_ESCAPE",
    "GLFW_KEY_ENTER",
    "GLFW_KEY_TAB",
    "GLFW_KEY_BACKSPACE",
    "GLFW_KEY_INSERT",
    "GLFW_KEY_DELETE",
    "GLFW_KEY_RIGHT",
    "GLFW_KEY_LEFT",
    "GLFW_KEY_DOWN",
    "GLFW_KEY_UP",
    "GLFW_KEY_PAGE_UP",
    "GLFW_KEY_PAGE_DOWN",
    "GLFW_KEY_HOME",
    "GLFW_KEY_END",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "GLFW_KEY_CAPS_LOCK",
    "GLFW_KEY_SCROLL_LOCK",
    "GLFW_KEY_NUM_LOCK",
    "GLFW_KEY_PRINT_SCREEN",
    "GLFW_KEY_PAUSE",
    "",
    "",
    "",
    "",
    "",
    "GLFW_KEY_F1",
    "GLFW_KEY_F2",
    "GLFW_KEY_F3",
    "GLFW_KEY_F4",
    "GLFW_KEY_F5",
    "GLFW_KEY_F6",
    "GLFW_KEY_F7",
    "GLFW_KEY_F8",
    "GLFW_KEY_F9",
    "GLFW_KEY_F10",
    "GLFW_KEY_F11",
    "GLFW_KEY_F12",
    "GLFW_KEY_F13",
    "GLFW_KEY_F14",
    "GLFW_KEY_F15",
    "GLFW_KEY_F16",
    "GLFW_KEY_F17",
    "GLFW_KEY_F18",
    "GLFW_KEY_F19",
    "GLFW_KEY_F20",
    "GLFW_KEY_F21",
    "GLFW_KEY_F22",
    "GLFW_KEY_F23",
    "GLFW_KEY_F24",
    "GLFW_KEY_F25",
    "",
    "",
    "",
    "",
    "",
    "GLFW_KEY_KP_0",
    "GLFW_KEY_KP_1",
    "GLFW_KEY_KP_2",
    "GLFW_KEY_KP_3",
    "GLFW_KEY_KP_4",
    "GLFW_KEY_KP_5",
    "GLFW_KEY_KP_6",
    "GLFW_KEY_KP_7",
    "GLFW_KEY_KP_8",
    "GLFW_KEY_KP_9",
    "GLFW_KEY_KP_DECIMAL",
    "GLFW_KEY_KP_DIVIDE",
    "GLFW_KEY_KP_MULTIPLY",
    "GLFW_KEY_KP_SUBTRACT",
    "GLFW_KEY_KP_ADD",
    "GLFW_KEY_KP_ENTER",
    "GLFW_KEY_KP_EQUAL",
    "",
    "",
    "",
    "GLFW_KEY_LEFT_SHIFT",
    "GLFW_KEY_LEFT_CONTROL",
    "GLFW_KEY_LEFT_ALT",
    "GLFW_KEY_LEFT_SUPER",
    "GLFW_KEY_RIGHT_SHIFT",
    "GLFW_KEY_RIGHT_CONTROL",
    "GLFW_KEY_RIGHT_ALT",
    "GLFW_KEY_RIGHT_SUPER",
    "GLFW_KEY_MENU"
};

    // class Shader {
    //     public:
    //         unsigned int ID;
    //         Shader(const char* vertexPath, const char* fragmentPath) { // constructor generates the shader on the fly
    //             // 1. retrieve the vertex/fragment source code from filePath
    //             std::string vertexCode;
    //             std::string fragmentCode;
    //             std::ifstream vShaderFile;
    //             std::ifstream fShaderFile;
    //             // ensure ifstream objects can throw exceptions:
    //             vShaderFile.exceptions (std::ifstream::failbit | std::ifstream::badbit);
    //             fShaderFile.exceptions (std::ifstream::failbit | std::ifstream::badbit);
    //             try {
                    
    //                 vShaderFile.open(vertexPath);   // open files
    //                 fShaderFile.open(fragmentPath); //
    //                 std::stringstream vShaderStream, fShaderStream;
    //                 vShaderStream << vShaderFile.rdbuf();   // read file's buffer contents into streams
    //                 fShaderStream << fShaderFile.rdbuf();   //
    //                 vShaderFile.close();    // close file handlers
    //                 fShaderFile.close();    //
    //                 vertexCode   = vShaderStream.str(); // convert stream into string
    //                 fragmentCode = fShaderStream.str(); //
    //             }
    //             catch (std::ifstream::failure& e) {
    //                 std::cout << "ERROR::SHADER::FILE_NOT_SUCCESSFULLY_READ: " << e.what() << std::endl; //send error
    //             }
    //             const char* vShaderCode = vertexCode.c_str();
    //             const char * fShaderCode = fragmentCode.c_str();
    //             // 2. compile shaders
    //             unsigned int vertex, fragment;
    //             vertex = glCreateShader(GL_VERTEX_SHADER);          // vertex shader
    //             glShaderSource(vertex, 1, &vShaderCode, NULL);      //
    //             glCompileShader(vertex);                            //
    //             checkCompileErrors(vertex, "VERTEX");               //
    //             fragment = glCreateShader(GL_FRAGMENT_SHADER);      // fragment Shader  
    //             glShaderSource(fragment, 1, &fShaderCode, NULL);    //
    //             glCompileShader(fragment);                          //
    //             checkCompileErrors(fragment, "FRAGMENT");           //
    //             ID = glCreateProgram();                             // shader Program
    //             glAttachShader(ID, vertex);                         //
    //             glAttachShader(ID, fragment);                       //
    //             glLinkProgram(ID);                                  //
    //             checkCompileErrors(ID, "PROGRAM");                  //
    //             glDeleteShader(vertex);                             // delete the shaders as they're linked into our program now and no longer necessary
    //             glDeleteShader(fragment);                           //
    //         }
    //         void use() {       // activate the shader
    //             glUseProgram(ID); 
    //         }
    //         void setBool(const std::string &name, bool value) const {           // utility uniform functions
    //             glUniform1i(glGetUniformLocation(ID, name.c_str()), (int)value); 
    //         }
    //         void setInt(const std::string &name, int value) const {             //
    //             glUniform1i(glGetUniformLocation(ID, name.c_str()), value); 
    //         }
    //         void setFloat(const std::string &name, float value) const {         //
    //             glUniform1f(glGetUniformLocation(ID, name.c_str()), value); 
    //         }
    //     private:
    //         void checkCompileErrors(unsigned int shader, std::string type) {    // utility function for checking shader compilation/linking errors.
    //             int success;
    //             char infoLog[1024];
    //             if (type != "PROGRAM") {
    //                 glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    //                 if (!success) {
    //                     glGetShaderInfoLog(shader, 1024, NULL, infoLog);
    //                     std::cout << "ERROR::SHADER_COMPILATION_ERROR of type: " << type << "\n" << infoLog << "\n -- --------------------------------------------------- -- " << std::endl;
    //                 }
    //             } else {
    //                 glGetProgramiv(shader, GL_LINK_STATUS, &success);
    //                 if (!success) {
    //                     glGetProgramInfoLog(shader, 1024, NULL, infoLog);
    //                     std::cout << "ERROR::PROGRAM_LINKING_ERROR of type: " << type << "\n" << infoLog << "\n -- --------------------------------------------------- -- " << std::endl;
    //                 }
    //             }
    //         }
    //         //Mistical::Console ConsoleClass;
    //     };


// class Texture {
    //     public:
    //         GLFWimage load(const char* path) {
    //             src.pixels = stbi_load(path, &src.width, &src.height, nullptr, 4);
    //         }
    //     private:
    //         GLFWimage src;
    // };

    
    // bool Window::WindowInput::WindowInputMouse::isReleased(int btn) {
    //     if (glfwGetKey(window.window, key) == GLFW_RELEASE) { return true; }
    //     return false;
    // }
    // bool Window::WindowInput::WindowInputMouse::isPressed(int btn) {
    //     if (glfwGetKey(window.window, key) == GLFW_PRESS) { return true; }
    //     return false;
    // }
    // bool Window::WindowInput::WindowInputMouse::wasPressed(int btn) {
    //     glfwGetCursorPos(window.window, &window.cursorPos[0], &window.cursorPos[1]);
    //     // https://www.glfw.org/docs/3.3/input_guide.html#input_mouse
    // }
    // bool Window::WindowInput::WindowInputMouse::wasReleased(int btn) {
    //     if (glfwGetKey(window.window, key) == GLFW_RELEASE && pressedKeys[key] == true) {
    //         pressedKeys[key] = false;
    //         return true;
    //     }
    //     checkKeyPress(key);
    //     return false;
    // }
