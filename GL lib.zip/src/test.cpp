#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "test.hpp"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

test::JSON _JSON_;
nlohmann::json Settings = _JSON_.ParseJSONFile("settings.json");
const unsigned int WIDTH = Settings["window"]["size"][0];
const unsigned int HEIGHT = Settings["window"]["size"][1];

int main() {
    std::cout << Settings << "\n";
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

    GLFWwindow* window = glfwCreateWindow(WIDTH, HEIGHT, Settings["window"]["title"].get<std::string>().c_str(), NULL, NULL);
    glfwMakeContextCurrent(window);

    gladLoadGLLoader((GLADloadproc)glfwGetProcAddress);

    glViewport(0, 0, WIDTH, HEIGHT);

    // Enable transparency
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    Shader shader(vertexShaderSrc, fragmentShaderSrc);

    // Projection (2D)
    glm::mat4 projection = glm::ortho(0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f);

    shader.use();
    shader.setMat4("projection", &projection[0][0]);

    Sprite sprite;
    sprite.Load(Settings["sprite"]["position"][0], Settings["sprite"]["position"][1], Settings["sprite"]["size"][0], Settings["sprite"]["size"][1], Settings["sprite"]["sprites"][0].get<std::string>().c_str());

    // Optional flip test
    // sprite.Flip(X);

    while (!glfwWindowShouldClose(window)) {
        glClear(GL_COLOR_BUFFER_BIT);

        shader.use();

        //sprite.Draw(Settings["sprite"]["position"][0], Settings["sprite"]["position"][1], Settings["sprite"]["size"][0], Settings["sprite"]["size"][1], shader);
        sprite.Draw(0.25f, 0.25f, 0.5f, 0.5f, shader);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}